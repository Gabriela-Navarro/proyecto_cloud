import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BackendService } from 'src/app/services/backend.service';
import { ShareDataService } from 'src/app/services/share-data.service';
import { registro } from '../models/registro';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.scss'],
})
export class RegistroComponent implements OnInit {
  formGroup: FormGroup = new FormGroup({});
  listado = new Array<registro>();
  constructor(
    private fb: FormBuilder,
    private share: ShareDataService,
    private router: Router,
    private backend1: BackendService
  ) {
    this.formGroup = this.fb.group({
      id: '',
      nombre: '',
      usuario: '',
      password: '',
      fecha_nac: '',
      genero: '',
    });
  }

  ngOnInit(): void {}

  borraringreso() {
    this.formGroup.patchValue({
      nombre: '',
      usuario: '',
      password: '',
      fecha_nac: '',
      genero: '',
    });
  }
  GrabarUsuario() {
    let listadoregistro = new registro(
      this.formGroup.controls['id'].value,
      this.formGroup.controls['nombre'].value,
      this.formGroup.controls['usuario'].value,
      this.formGroup.controls['password'].value,
      this.formGroup.controls['fecha_nac'].value,
      this.formGroup.controls['genero'].value
    );
    this.backend1.insertarRegistro(listadoregistro).subscribe((x) => {
      console.log('Respuesta:' + x);
      this.borraringreso();
    });
  }
  regresar() {
    this.router.navigateByUrl('');
  }
}
