import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuxiliaturasComponent } from './auxiliaturas.component';

describe('AuxiliaturasComponent', () => {
  let component: AuxiliaturasComponent;
  let fixture: ComponentFixture<AuxiliaturasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AuxiliaturasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AuxiliaturasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
