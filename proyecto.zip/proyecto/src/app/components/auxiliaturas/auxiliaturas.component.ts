import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { auxiliaturas } from '../models/auxiliaturas';
import { BackendService } from 'src/app/services/backend.service';
import { ShareDataService } from 'src/app/services/share-data.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-auxiliaturas',
  templateUrl: './auxiliaturas.component.html',
  styleUrls: ['./auxiliaturas.component.scss']
})
export class AuxiliaturasComponent implements OnInit {
  formGroup: FormGroup = new FormGroup({});
  listado = new Array<auxiliaturas>();
  constructor(
    private fb: FormBuilder,
    private share: ShareDataService,
    private router: Router,
    private backend1: BackendService
  ) { 
    this.formGroup = this.fb.group({
      nombre: '',
      correo: '',
      celular: '',
      fecha_nac: '',
      facultad: '',
      carnet: '',
      curso: '',
      seccion: '',
      genero: '',
    });
  }

  ngOnInit(): void {
  }
  borraringreso() {
    this.formGroup.patchValue({
      nombre: '',
      correo: '',
      celular: '',
      fecha_nac: '',
      facultad: '',
      carnet: '',
      curso: '',
      seccion: '',
      genero: '',
    });
  }
  guardarAuxiliar() {
    let listadoauxiliar = new auxiliaturas(
      this.formGroup.controls['nombre'].value,
      this.formGroup.controls['correo'].value,
      this.formGroup.controls['celular'].value,
      this.formGroup.controls['fecha_nac'].value,
      this.formGroup.controls['facultad'].value,
      this.formGroup.controls['carnet'].value,
      this.formGroup.controls['curso'].value,
      this.formGroup.controls['seccion'].value,
      this.formGroup.controls['genero'].value
    );
    this.backend1.insertarAuxiliar(listadoauxiliar).subscribe((x) => {
      console.log('Respuesta:' + x);
      this.borraringreso();
    });
  }

  regresar() {
    this.router.navigateByUrl('/menu');
  }
}
