import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { BackendService } from 'src/app/services/backend.service';
import { ShareDataService } from 'src/app/services/share-data.service';
import { alumnos } from '../models/alumnos';

@Component({
  selector: 'app-consultar',
  templateUrl: './consultar.component.html',
  styleUrls: ['./consultar.component.scss'],
})
export class ConsultarComponent implements OnInit {
  dataSource = new MatTableDataSource(new Array<alumnos>());
  displayedColumns = [
    'curso',
    'nota',
    'descripcion',
    'catedratico',
    
  ];

  constructor(
    private share: ShareDataService,
    private router: Router,
    private backend2: BackendService
  ) {}

  ngOnInit(): void {
    this.backend2.obtenerAlumnos().subscribe((x) => {
      this.dataSource.data = x.datos;
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  regresar() {
    this.router.navigateByUrl('/menu');
  }

  
}
