import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BackendService } from 'src/app/services/backend.service';
import { ShareDataService } from 'src/app/services/share-data.service';
import { LoginRequest } from '../models/LoginRequest';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private share: ShareDataService,
    private backend: BackendService
  ) {}

  ingreso = { usuario: '', password: '' };
  usuario: string = '';
  password: string = '';

  login() {
    console.log(this.usuario);
    console.log(this.password);
    this.backend.login(this.ingreso).subscribe((data) => {
      console.log(data);
      this.router.navigateByUrl('/menu');
    });
  }

  ngOnInit(): void {
    
  }

  registro() {
    this.router.navigateByUrl('/registro');
  }
  regresar() {
    this.router.navigateByUrl('');
  }
}
