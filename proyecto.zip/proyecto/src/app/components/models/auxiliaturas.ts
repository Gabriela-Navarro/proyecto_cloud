export class auxiliaturas {
    nombre: string;
    correo: string;
    celular: number;
    fecha_nac: Date; 
    facultad: string;
    carnet: number;
    curso: string;
    seccion: string;
    genero: string;
    constructor(
    nombre: string,
    correo: string,
    celular: number,
    fecha_nac: Date,
    facultad: string,
    carnet: number,
    curso: string,
    seccion: string,
    genero: string
    ) {
      this.nombre = nombre;
      this.correo = correo;
      this.celular = celular;
      this.fecha_nac = fecha_nac;
      this.facultad = facultad;
      this.carnet = carnet;
      this.curso = curso;
      this.seccion = seccion;
      this.genero = genero;
      
    }
  }
  