export class LoginResponse {
  status: number;
  mensajes: string;
  key: string;

  constructor(status: number, mensajes: string, key: string) {
    this.status = status;
    this.mensajes = mensajes;
    this.key = key;
  }
}
