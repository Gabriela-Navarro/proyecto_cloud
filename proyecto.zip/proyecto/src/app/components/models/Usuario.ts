export class Usuario {
  usuario: string;
  contra: string;
  constructor(usuario: string, contra: string) {
    this.usuario = usuario;
    this.contra = contra;
  }
}
