export class alumnos {
    id: number;
    curso: string;
    nota: number;
    descripcion: string;
    catedratico: string;
    constructor(
      id: number,
      curso: string,
      nota: number,
      descripcion: string,
      catedratico: string
    ) {
      this.id = id;
      this.curso = curso;
      this.nota = nota;
      this.descripcion = descripcion;
      this.catedratico= catedratico;
    }
  }
  