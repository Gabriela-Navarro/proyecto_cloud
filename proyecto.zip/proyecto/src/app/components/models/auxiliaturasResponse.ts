import { auxiliaturas } from './auxiliaturas';

export class AuxiliaturasResponse {
  id: number;
  mensajes: string;
  datos: Array<auxiliaturas>;

  constructor(id: number, mensajes: string, datos: Array<auxiliaturas>) {
    this.id = id;
    this.mensajes = mensajes;
    this.datos = datos;
  }
}
