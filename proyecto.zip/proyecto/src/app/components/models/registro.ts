export class registro {
  id: number;
  nombre: string;
  usuario: string;
  password: string;
  fecha_nac: Date;
  genero: string;
  constructor(
    id: number,
    nombre: string,
    usuario: string,
    password: string,
    fecha_nac: Date,
    genero: string
  ) {
    this.id = id;
    this.nombre = nombre;
    this.usuario = usuario;
    this.password = password;
    this.fecha_nac = fecha_nac;
    this.genero = genero;
  }
}
