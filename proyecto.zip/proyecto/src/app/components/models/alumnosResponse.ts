import { alumnos } from './alumnos';

export class alumnosResponse {
  id: number;
  mensajes: string;
  datos: Array<alumnos>;

  constructor(id: number, mensajes: string, datos: Array<alumnos>) {
    this.id = id;
    this.mensajes = mensajes;
    this.datos = datos;
  }
}
