import { registro } from './registro';

export class registroResponse {
  id: number;
  mensajes: string;
  datos: Array<registro>;

  constructor(id: number, mensajes: string, datos: Array<registro>) {
    this.id = id;
    this.mensajes = mensajes;
    this.datos = datos;
  }
}
