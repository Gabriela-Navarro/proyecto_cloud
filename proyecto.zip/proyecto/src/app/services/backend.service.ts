import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { registro } from '../components/models/registro';
import { registroResponse } from '../components/models/registroResponse';
import { LoginRequest } from '../components/models/LoginRequest';
import { LoginResponse } from '../components/models/LoginResponse';
import { alumnos } from '../components/models/alumnos';
import { alumnosResponse } from '../components/models/alumnosResponse';
import { auxiliaturas } from '../components/models/auxiliaturas';
import { AuxiliaturasResponse } from '../components/models/auxiliaturasResponse';

const be_api = environment.api_backend;
const httoption = {
  headers: new HttpHeaders().set('Content-Type', 'application/json'),
};

@Injectable({
  providedIn: 'root',
})
export class BackendService {
  constructor(private httpClient: HttpClient) {}

  insertarAlumnos(prueba: alumnos) {
    console.log(be_api + '/alumnos');
    console.log(prueba);
    return this.httpClient.post<alumnosResponse>(
      be_api + '/alumnos',
      prueba,
      httoption
    );
  }

  obtenerAlumnos() {
    return this.httpClient.get<alumnosResponse>(be_api + '/alumnos', httoption);
  }

  eliminar() {
    return this.httpClient.delete<alumnosResponse>(
      be_api + '/alumnos',
      httoption
    );
  }
  insertarRegistro(prueba: registro) {
    console.log(be_api + '/registro');
    console.log(prueba);
    return this.httpClient.post<registroResponse>(
      be_api + '/registro',
      prueba,
      httoption
    );
  }
  insertarAuxiliar(prueba: auxiliaturas) {
    console.log(be_api + '/aux');
    console.log(prueba);
    return this.httpClient.post<AuxiliaturasResponse>(
      be_api + '/aux',
      prueba,
      httoption
    );
  }
 


  login(user: LoginRequest) {
    console.log(be_api + '/login');
    console.log(user);
    return this.httpClient.post<LoginResponse>(
      be_api + '/login',
      user,
      httoption
    );
  }

  delete(id: string) {
    return this.httpClient.delete(be_api + '/login' + id, httoption);
  }
}
