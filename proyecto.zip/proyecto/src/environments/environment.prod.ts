export const environment = {
  production: true,
  api_backend: 'http://localhost:5000',
};
