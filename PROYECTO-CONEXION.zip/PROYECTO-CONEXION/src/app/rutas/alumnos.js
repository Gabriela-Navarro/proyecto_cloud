const conn = require('../../config/database');

module.exports = (app) => {

    // INGRESAR COMICS
    //consultar
    app.get('/alumnos', (req, res) =>{
        let query = 'SELECT curso,nota,descripcion,catedratico FROM alumnos';
        conn.query(query, (error, filas) => {
            if (error) {
                res.json({status: 0, mensaje: "Error en DB", datos: []});
            } else {
                res.json({status: 1, mensaje: "Datos obtenidos", datos: filas});
            }
        }); 
    });
    // insertar valor
    app.post('/alumnos', (req, res) =>{
        let query = `INSERT INTO alumnos (curso,nota,descripcion,catedratico FROM alumnos) VALUES ('${req.body.curso}','${req.body.nota}', '${req.body.descripcion}','${req.body.catedratico}')`; 
        conn.query(query, (error, filas) => {
            if (error) {
                res.json({status: 0, mensaje: "Error en DB", datos: []});
            } else {
                res.json({status: 1, mensaje: "Datos ingresados", datos: []});
            }
        }); 
    });

    app.get('/registro', (req, res) =>{
        let query = 'SELECT nombre,usuario,password,fecha_nac,genero FROM registro';
        conn.query(query, (error, filas) => {
            if (error) {
                res.json({status: 0, mensaje: "Error en DB", datos: []});
            } else {
                res.json({status: 1, mensaje: "Datos obtenidos", datos: filas});
            }
        }); 
    });
    // insertar valor
    app.post('/registro', (req, res) =>{
        let query = `INSERT INTO registro (nombre, usuario,password,fecha_nac,genero) VALUES ('${req.body.nombre}','${req.body.usuario}','${req.body.password}', '${req.body.fecha_nac}','${req.body.genero}')`; 
        conn.query(query, (error, filas) => {
            if (error) {
                res.json({status: 0, mensaje: "Error en DB", datos: []});
            } else {
                res.json({status: 1, mensaje: "Datos ingresados", datos: []});
            }
        }); 
    });


    

    app.post('/login', (req, res) =>{
        let query = `SELECT id, nombre,usuario, password, fecha_nac , genero FROM registro WHERE 
        usuario = '${req.body.usuario}' AND password = '${req.body.password}'`;
        console.log(query);
        conn.query(query, (err, rows, cols) => {
            if (err)  {
                res.status(500).json({status:0, mensaje: "Err Base de datos"});
            } else {
                if (rows.length > 0) {
                    res.json({status: 1, mensaje: "usuario exitoso",  datos:cols});
                } else {
                    res.status(400).json({status: 0, mensaje: "no se encontro usuario que coinsida con la clave"});
                }
            }
        })
    });


    app.get('/auxiliaturas', (req, res) =>{
        let query = 'SELECT nombre ,correo,celular,fecha_nac,facultad, carnet, curso , seccion,genero FROM auxiliaturas';
        conn.query(query, (error, filas) => {
            if (error) {
                res.json({status: 0, mensaje: "Error en DB", datos: []});
            } else {
                res.json({status: 1, mensaje: "Datos obtenidos", datos: filas});
            }
        }); 
    });
    // insertar valor
    app.post('/aux', (req, res) =>{
        let query = `INSERT INTO auxiliaturas (nombre,correo,celular,fecha_nac,facultad, carnet, curso , seccion,genero ) VALUES ('${req.body.nombre}','${req.body.correo}','${req.body.celular}', '${req.body.fecha_nac}','${req.body.facultad}' ,'${req.body.carnet}' ,'${req.body.curso}' ,'${req.body.seccion}' ,'${req.body.genero}')`; 
        conn.query(query, (error, filas) => {
            if (error) {
                res.json({status: 0, mensaje: "Error en DB", datos: []});
            } else {
                res.json({status: 1, mensaje: "Datos ingresados", datos: []});
            }
        }); 
    });

   

}


