const db = require('mysql');
const conn = db.createConnection({
    host:'proyectocloud.mysql.database.azure.com',
    user:'Gabriela',
    password:'GNav3232',
     database:"proyectocloud"
    
});
conn.connect((error) => {
    if (error){
    console.log("Error en el servidor");
    } else{
    console.log("Servidor corriendo en Mysql");
    }
});


module.exports = conn;

